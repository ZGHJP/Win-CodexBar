CodexBar 0.70.0-jp.6 - Windows x64

解压完整目录，退出已有 CodexBar 并等待辅助进程结束，然后运行 Install.cmd。
需要网络下载约 38 MB 的已编译程序，以及系统 WebView2 Runtime。
不需要安装 Python、Rust 或 Visual Studio，不要求管理员权限。

本包修复 Codex 登录时 persist_failed / atomic credential replacement does not support hard-linked files。
凭据和配置改用保留访问权限的独立副本；数据库通过 SQLite 一致性快照读取。
升级会清理可识别的标准和商店版缓存兼容目录内的旧链接，不删除原始凭据或清空回收站。
原始凭据更新通常在下一轮约 15 秒同步；退出登录后移除兼容副本。

编译的桌面程序、CLI 和运行时来自已校验的 jp.5 发布包，兼容层和安装逻辑更新到 jp.6。
本次没有更改 Rust / 前端源码，也没有重新编译这些相同组件；安装清单分别记录两部分的源码与版本。
因此“关于”页中的原生编译号仍可能显示 jp.5-gh-15，这不等于兼容层未升级。
凭据修复源码：dbfbd8d1a730769529dfb8e31f74cefb366a6043
原生编译源码：da129a9214961540aa41a0a40fb1dea35fdba935
原生完整 ZIP SHA256：de7a26d89a001194a4b14d9702df615ec132eb49e2142b35fa7933ce497f7623

本包不含账户、真实日志或用量数据库。请使用目标电脑自己的 Codex 登录。
美元仍是 API 等价估算；此次未实现订阅/credits 或完整 Fast 计费。
不要单独安装旧 jp.5 来验证此凭据修复；必须通过本入口或后续正式 jp.6 完整包升级。
不要重新运行旧辅助脚本备份，它们可能重建硬链接。
